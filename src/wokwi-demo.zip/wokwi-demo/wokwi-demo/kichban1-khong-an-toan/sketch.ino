/*
  ============================================================
  KỊCH BẢN 1 - CHƯA AN TOÀN (minh chứng lỗi bảo mật)
  Đề tài: Checklist kiểm tra bảo mật thiết bị IoT trước triển khai
  Mô phỏng: ESP32 + DHT22 trên Wokwi

  Các lỗi bảo mật CỐ Ý đưa vào để đối chiếu checklist (Chương 4):
    [L1] WiFi/MQTT thông tin đăng nhập hardcode thẳng trong source
    [L2] Kết nối MQTT qua cổng 1883: KHÔNG mã hoá (plaintext TCP)
    [L3] KHÔNG có username/password khi connect broker (anonymous)
    [L4] clientID cố định -> nguy cơ trùng lặp / bị giành session
    [L5] Payload gửi dạng JSON thô, không mã hoá, không ký số
  => Ai bắt được gói tin trên đường truyền, hoặc subscribe vào
     broker công khai, đều đọc được nguyên văn dữ liệu cảm biến.

  CHỈ DÙNG TRONG MÔI TRƯỜNG MÔ PHỎNG (Wokwi + broker test công khai).
  KHÔNG áp dụng cấu hình này cho thiết bị triển khai thực tế.
  ============================================================
*/

#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>

// ---- [L1] Hardcode thông tin đăng nhập ----
const char* WIFI_SSID = "Wokwi-GUEST";   // mạng WiFi ảo mặc định của Wokwi
const char* WIFI_PASS = "";

// ---- [L2] Broker test công khai, cổng plaintext ----
const char* MQTT_SERVER = "test.mosquitto.org";
const int   MQTT_PORT   = 1883;          // không TLS

// ---- [L3][L4] Không auth, clientID cố định ----
const char* MQTT_CLIENT_ID = "esp32-demo-01";
const char* MQTT_TOPIC = "khoaluan/demo/khongantoan/cambien";

#define DHTPIN  4
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);
WiFiClient   espClient;
PubSubClient mqtt(espClient);

unsigned long lastMsg = 0;

void connectWiFi() {
  Serial.print("[WiFi] Dang ket noi toi ");
  Serial.println(WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  while (WiFi.status() != WL_CONNECTED) {
    delay(300);
    Serial.print(".");
  }
  Serial.println();
  Serial.print("[WiFi] Da ket noi, IP: ");
  Serial.println(WiFi.localIP());
}

void reconnectMQTT() {
  Serial.print("[MQTT] Dang ket noi (KHONG TLS, KHONG AUTH)... ");
  // [L3] connect() chỉ truyền clientID, không có user/pass
  if (mqtt.connect(MQTT_CLIENT_ID)) {
    Serial.println("OK");
  } else {
    Serial.print("That bai, rc=");
    Serial.print(mqtt.state());
    Serial.println(" -> thu lai sau 2s");
  }
}

void setup() {
  Serial.begin(115200);
  delay(300);
  dht.begin();

  connectWiFi();
  mqtt.setServer(MQTT_SERVER, MQTT_PORT);
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    connectWiFi();
  }

  if (!mqtt.connected()) {
    reconnectMQTT();
    delay(2000); // tránh spam broker liên tục
    return;
  }
  mqtt.loop();

  unsigned long now = millis();
  if (now - lastMsg > 5000) {
    lastMsg = now;

    float t = dht.readTemperature();
    float h = dht.readHumidity();

    if (isnan(t) || isnan(h)) {
      Serial.println("[Sensor] Loi doc du lieu tu DHT22!");
      return;
    }

    // [L5] Payload plaintext, không mã hoá
    String payload = "{\"nhiet_do\":" + String(t, 1) +
                      ",\"do_am\":" + String(h, 1) + "}";

    Serial.print("[MQTT] Publish (KHONG MA HOA) toi topic '");
    Serial.print(MQTT_TOPIC);
    Serial.print("': ");
    Serial.println(payload);

    mqtt.publish(MQTT_TOPIC, payload.c_str());
  }
}
