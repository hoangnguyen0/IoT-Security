# Wokwi Demo — 2 kịch bản minh chứng checklist bảo mật IoT

Dùng cho Mục 4.3–4.4 của đề tài: chứng minh hậu quả lỗi bảo mật phổ biến
(kịch bản 1) và hiệu quả biện pháp khắc phục (kịch bản 2), trên cùng một
mô hình phần cứng ESP32 + DHT22.

## Cách chạy trên Wokwi

1. Vào https://wokwi.com/projects/new/esp32
2. Mở tab `sketch.ino`, xoá nội dung mặc định, dán nội dung file
   `sketch.ino` tương ứng (kịch bản 1 hoặc 2).
3. Mở tab `diagram.json`, thay bằng nội dung file `diagram.json` tương ứng.
4. Mở tab `libraries.txt`, dán nội dung file `libraries.txt` (Wokwi sẽ tự
   cài 3 thư viện: DHT sensor library, Adafruit Unified Sensor, PubSubClient).
5. Bấm nút play (▶) để chạy mô phỏng, mở Serial Monitor để xem log.
6. Có thể mở thêm một client MQTT thật (MQTT Explorer, hoặc lệnh
   `mosquitto_sub`) để subscribe cùng topic và quan sát:
   - Kịch bản 1: dữ liệu đọc được nguyên văn (plaintext) → minh chứng
     lỗi "dịch vụ mạng không an toàn" / "dữ liệu không mã hoá".
   - Kịch bản 2: kết nối bắt buộc qua TLS + username/password đúng mới
     đọc được → minh chứng đã khắc phục.

## Đối chiếu nhanh với checklist

| Tiêu chí (nhóm) | Kịch bản 1 | Kịch bản 2 |
|---|---|---|
| Mã hoá đường truyền (Giao thức) | Chưa đạt — cổng 1883, plaintext | Đạt — TLS cổng 8885 |
| Xác thực kết nối broker (Giao thức) | Chưa đạt — anonymous | Đạt — username/password |
| Định danh thiết bị duy nhất (Vận hành) | Chưa đạt — clientID cố định | Đạt — clientID theo MAC |
| Xác thực server certificate (Giao thức) | Không áp dụng | Nên có — bật `USE_CA_CERT=1` + dán CA thật |

## Lưu ý an toàn khi dùng cho báo cáo

- Đây là broker **test công khai** (test.mosquitto.org) — chỉ dùng dữ
  liệu giả lập, không publish thông tin thật, không dùng topic trùng với
  người khác đang test (nên đặt tiền tố riêng, ví dụ `khoaluan/<mssv>/...`).
- Trong kịch bản 2, `USE_CA_CERT=0` (dùng `setInsecure()`) chỉ để chạy
  nhanh trên Wokwi mà không cần thao tác dán chứng chỉ; bản thân đây vẫn
  là một hạn chế cần ghi nhận trong checklist (chưa xác thực server certificate).
  Muốn đạt mức khắc phục đầy đủ, tải `mosquitto.org.crt` tại
  https://test.mosquitto.org/ssl/mosquitto.org.crt, dán vào biến
  `MQTT_CA_CERT` trong sketch, rồi đặt `USE_CA_CERT=1`.
- Không áp dụng thông tin đăng nhập/broker này cho thiết bị triển khai
  thực tế — đây chỉ là môi trường mô phỏng phục vụ minh chứng học thuật.
