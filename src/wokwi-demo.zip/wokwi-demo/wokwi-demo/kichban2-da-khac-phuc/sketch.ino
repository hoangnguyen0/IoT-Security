/*
  ============================================================
  KỊCH BẢN 2 - ĐÃ KHẮC PHỤC (đối chiếu kịch bản 1)
  Đề tài: Checklist kiểm tra bảo mật thiết bị IoT trước triển khai

  Biện pháp khắc phục áp dụng, ánh xạ trực tiếp với các lỗi [L1]-[L5]
  của kịch bản 1:
    [F2] Kết nối MQTT qua TLS (cổng 8885) -> mã hoá đường truyền
    [F3] Xác thực bằng username/password -> không còn anonymous
    [F4] clientID duy nhất theo địa chỉ MAC -> tránh trùng phiên
    [F5] Payload vẫn JSON nhưng đã được bảo vệ bởi kênh TLS
    [F+] Cơ chế reconnect có backoff tăng dần, tránh spam broker

  LƯU Ý QUAN TRỌNG:
  - username/password/topic dưới đây dùng broker TEST CÔNG KHAI
    (test.mosquitto.org) CHỈ để minh hoạ trong Wokwi.
  - Khi triển khai thật: dùng broker riêng, mật khẩu mạnh KHÔNG
    hardcode (đọc từ NVS/Preferences hoặc qua bước provisioning),
    và chứng chỉ CA do đơn vị mình cấp/quản lý.
  - Biến USE_CA_CERT bên dưới cho phép chọn giữa 2 mức xác thực TLS:
      0 = setInsecure()  -> mã hoá kênh truyền, chạy ngay không cần
                            dán chứng chỉ (dùng để demo nhanh trên Wokwi)
      1 = setCACert(...) -> xác thực luôn cả server certificate,
                            chống MITM (khuyến nghị khi báo cáo/nộp bài,
                            cần dán nội dung mosquitto.org.crt vào bên dưới)
  ============================================================
*/

#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <DHT.h>

#define USE_CA_CERT 0   // đổi thành 1 sau khi đã dán chứng chỉ CA thật

const char* WIFI_SSID = "Wokwi-GUEST";
const char* WIFI_PASS = "";

const char* MQTT_SERVER = "test.mosquitto.org";
const int   MQTT_PORT   = 8885;          // TLS + username/password
const char* MQTT_USER   = "rw";
const char* MQTT_PASS   = "readwrite";
const char* MQTT_TOPIC  = "demo/dakhacphuc/cambien";

// Tải file gốc tại: https://test.mosquitto.org/ssl/mosquitto.org.crt
// rồi dán TOÀN BỘ nội dung (gồm cả dòng BEGIN/END CERTIFICATE) vào đây,
// đồng thời đặt USE_CA_CERT = 1 ở trên.
const char* MQTT_CA_CERT = R"EOF(
-----BEGIN CERTIFICATE-----
DAN_NOI_DUNG_CHUNG_CHI_CA_TAI_DAY
-----END CERTIFICATE-----
)EOF";

#define DHTPIN  4
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);
WiFiClientSecure espClient;
PubSubClient     mqtt(espClient);

unsigned long lastMsg = 0;
unsigned long reconnectDelay = 2000;
String clientId;

void connectWiFi() {
  Serial.print("[WiFi] Dang ket noi toi ");
  Serial.println(WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  while (WiFi.status() != WL_CONNECTED) {
    delay(300);
    Serial.print(".");
  }
  Serial.println();
  Serial.print("[WiFi] Da ket noi, IP: ");
  Serial.println(WiFi.localIP());
}

void reconnectMQTT() {
  Serial.print("[MQTT] Dang ket noi qua TLS + xac thuc... ");
  if (mqtt.connect(clientId.c_str())) {
    Serial.println("OK");
    reconnectDelay = 2000; // reset backoff khi thành công
  } else {
    Serial.print("That bai, rc=");
    Serial.print(mqtt.state());
    Serial.print(" -> thu lai sau ");
    Serial.print(reconnectDelay / 1000);
    Serial.println("s");
    delay(reconnectDelay);
    if (reconnectDelay < 30000) reconnectDelay *= 2; // backoff tang dan
  }
}

void setup() {
  Serial.begin(115200);
  delay(300);
  dht.begin();

  // [F4] clientID duy nhất theo MAC, không còn cố định
  clientId = "esp32-secure-" + String((uint32_t)(ESP.getEfuseMac() >> 16), HEX);

  connectWiFi();

#if USE_CA_CERT
  espClient.setCACert(MQTT_CA_CERT);       // xác thực server certificate
#else
  espClient.setInsecure();                  // demo nhanh: chỉ mã hoá, chưa xác thực CA
#endif

  mqtt.setServer(MQTT_SERVER, MQTT_PORT);
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    connectWiFi();
  }

  if (!mqtt.connected()) {
    reconnectMQTT();
    return;
  }
  mqtt.loop();

  unsigned long now = millis();
  if (now - lastMsg > 5000) {
    lastMsg = now;

    float t = dht.readTemperature();
    float h = dht.readHumidity();

    if (isnan(t) || isnan(h)) {
      Serial.println("[Sensor] Loi doc du lieu tu DHT22!");
      return;
    }

    String payload = "{\"nhiet_do\":" + String(t, 1) +
                      ",\"do_am\":" + String(h, 1) + "}";

    Serial.print("[MQTT] Publish (TLS + AUTH) toi topic '");
    Serial.print(MQTT_TOPIC);
    Serial.print("': ");
    Serial.println(payload);

    mqtt.publish(MQTT_TOPIC, payload.c_str());
  }
}
